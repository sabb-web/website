<?php
/**
 * Title: About centered text
 * Slug: purple/about-centered-text
 * Categories: about, purple
 * Keywords: about, text
 * Description: A description section aligned center.
 * Viewport width: 1440
 *
 * @package purple
 */

?>

<!-- wp:group {"metadata":{"name":"Centered text","patternName":"purple/about-centered-text","description":"A description section aligned center.","categories":["about","purple"]},"align":"full","style":{"spacing":{"margin":{"top":"0","bottom":"0"},"padding":{"top":"var:preset|spacing|140","bottom":"var:preset|spacing|140"}},"elements":{"link":{"color":{"text":"var:preset|color|theme-2"}}}},"textColor":"theme-2","layout":{"type":"constrained"}} -->
<div class="wp-block-group alignfull has-theme-2-color has-text-color has-link-color" style="margin-top:0;margin-bottom:0;padding-top:var(--wp--preset--spacing--140);padding-bottom:var(--wp--preset--spacing--140)"><!-- wp:paragraph {"style":{"typography":{"textAlign":"center"}},"fontSize":"large"} -->
<p class="has-text-align-center has-large-font-size"><?php esc_html_e( 'Our products are crafted with meticulous attention to quality, using only the finest materials and ingredients. Designed to deliver exceptional performance, each item undergoes rigorous testing to ensure it meets the highest standards.', 'purple' );?></p>
<!-- /wp:paragraph --></div>
<!-- /wp:group -->
