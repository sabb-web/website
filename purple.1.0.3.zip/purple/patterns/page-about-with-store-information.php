<?php
/**
 * Title: About page with store information
 * Slug: purple/page-about-with-store-information
 * Categories: purple
 * Keywords: starter
 * Description: An about page with store features, intro sections, and a features list with image.
 * Block Types: core/post-content
 * Post Types: page, wp_template
 * Viewport width: 1440
 *
 * @package purple
 */

?>

<!-- wp:pattern {"slug":"purple/store-features-three-columns-alternative"} /-->
<!-- wp:pattern {"slug":"purple/about-left-aligned-text-right-image"} /-->
<!-- wp:pattern {"slug":"purple/about-centered-text"} /-->
<!-- wp:pattern {"slug":"purple/about-left-aligned-image-right-text"} /-->
<!-- wp:pattern {"slug":"purple/about-features-2-columns"} /-->
